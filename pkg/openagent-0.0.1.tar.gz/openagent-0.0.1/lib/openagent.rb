require 'rubygems'
require 'uuid'
require 'roxml'

require 'openagent/messages'


module OpenAgent


end