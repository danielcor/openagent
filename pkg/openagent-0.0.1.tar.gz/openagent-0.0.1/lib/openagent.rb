require 'rubygems'
require 'uuid'
require 'roxml'

module OpenAgent

  autoload :Messages, "openagent/messages.rb"

end