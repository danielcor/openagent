require 'rubygems'
require 'uuid'
require 'roxml'

module OpenAgent

  autoload :Messages, "openagent/messages"

end